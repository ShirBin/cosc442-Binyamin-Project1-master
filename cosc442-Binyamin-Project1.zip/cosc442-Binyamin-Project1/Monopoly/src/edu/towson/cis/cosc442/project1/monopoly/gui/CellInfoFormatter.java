package edu.towson.cis.cosc442.project1.monopoly.gui;

import edu.towson.cosc442.project1.monopoly.IOwnable;

public interface CellInfoFormatter {
    public String format(IOwnable cell);
}
