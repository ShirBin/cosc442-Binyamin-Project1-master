package edu.towson.cosc442.project1.monopoly;

// TODO: Auto-generated Javadoc
/**
 * The Interface RespondDialog.
 */
public interface RespondDialog {
    
    /**
     * Gets the response.
     *
     * @return the response
     */
    boolean getResponse();
}
